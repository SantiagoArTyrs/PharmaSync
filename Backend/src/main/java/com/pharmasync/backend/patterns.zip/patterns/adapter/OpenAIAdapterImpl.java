package com.pharmasync.backend.patterns.adapter;

import com.pharmasync.backend.model.ChatMessage;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

@Component
public class OpenAIAdapterImpl implements AIResponseAdapter {

    @Override
    public ChatMessage adapt(String externalResponse, String sessionId) {
        return ChatMessage.builder()
                .id(UUID.randomUUID().toString())
                .sessionId(sessionId)
                .sender("assistant")
                .content(cleanContent(externalResponse))
                .timestamp(Instant.now())
                .build();
    }

    private String cleanContent(String raw) {
        // Aquí puedes limpiar etiquetas innecesarias, HTML, encabezados, etc.
        return raw.trim();
    }
}
