package com.pharmasync.backend.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class OpenAIClient {

    @Value("${n8n.webhook.url:http://localhost:5678/webhook/agent}")
    private String n8nWebhookUrl; // define esto en tu application-dev.yml

    private final WebClient.Builder webClientBuilder;

    public String call(String prompt) {
        return webClientBuilder.build()
                .post()
                .uri(n8nWebhookUrl)
                .bodyValue(new PromptRequest(prompt))
                .retrieve()
                .bodyToMono(PromptResponse.class)
                .map(PromptResponse::respuesta)
                .block(); // síncrono para mantener lógica simple
    }

    private record PromptRequest(String message) {}

    private record PromptResponse(String respuesta) {}
}
